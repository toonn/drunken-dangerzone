package chatserver;
/**
 * The ChatServerMain class will start the chatserver
 */

public class ChatServerMain {
	public static void main(String[] args) {
		chatServer = new ChatServer();
	}
	
	public static ChatServer chatServer;
}